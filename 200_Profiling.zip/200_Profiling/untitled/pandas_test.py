import pandas

print(pandas.read_csv('test.csv'))
